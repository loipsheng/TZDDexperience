The folders LC_application and LC_random store the application benchmarks and random benchmarks of EDPLLSim input format respectively.

The files in LC_random represents a linear constraint system with boundary.
The first of them is two non negative integers N M, which indicates that there are N variables and M constraints in the system.
Next are N pairs of integers, representing the value boundaries of nN variables.
Next is the matrix of M * (N + 1), representing the variable coefficients and constant coefficients in the M constraints.

The slight difference between files in LC_application and files in LC_random lies in that the former may contain multiple constraint systems.
Therefore, they will start with a non negative integer N and be followed by N systems with similar structures to those in LC_random.

The folders in xcsp_random store the random benchmarks of cn2mddg.

In addition to LC and xcsp format benchmarks, there are also formats for IntCount and Barvinok, namely Poly, as well as CNF format.
Poly format benchmarks with the counters IntCount and Barvinok can be obtained in project IntCount.

CNF format benchmarks is too large to presented directly in this project.
You can convert an LC format random benchmarks into a CNF file using the following command:
./LC2SMT_Rand <LC system file>
./boolector -dd tmp.smt > <CNF file>

Similarly, for the linear constraint system in the application benchmarks, only LC2SMT_Rand needs to be changed to LC2SMT_App.

LC2SMT_Rand, LC2SMT_App and boolector can be found in folder tools/
