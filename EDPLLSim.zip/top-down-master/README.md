1. Before compilation
The compilation of EDPLLSim relies on two GNU libraries: GMP and GLPK.
You can install them by executing the script: ./build_utils.sh

2. To compile EDPLLSim
You can EDPLLSim by executing the script: ./build.sh

3. To use EDPLLSim
You can try to use EDPLLSim to calculate the number of integer solutions to the linear constraints like this:
./EDPLLSim examples/5_1_1.in
./EDPLLSim examples/5_5_5.in
./EDPLLSim examples/6_5_4.in
./EDPLLSim examples/6_6_6.in

