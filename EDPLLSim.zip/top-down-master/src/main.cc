#include <chrono>
#include <fstream>
#include <iostream>

#include "linear_constraint.h"
#include "solver.h"

using namespace std;

int StrToInt(const string& str) {
  int res = 0;
  try {
    res = stoi(str);
  } catch (...) {
    cerr << "StrToInt fail: str [" << str << "]" << endl;
  }
  return res;
}

int main(int argc, char *argv[]) {
  if (argc < 2) {
    cerr << "Too few parameters" << endl;
    return -1;
  }

  string in_path;
  for (int i = 1; i < argc; i++) {
    if (argv[i][0] != '-') in_path = argv[i];
    else {
      string param = argv[i] + 1;
      auto pos = param.find('=');
      if (pos == string::npos) {
        cerr << "Warning: unknow parameter [" << param << "]" << endl;
        continue;
      }

      string k = param.substr(0, pos);
      string v = param.substr(pos + 1);
      if (k == "ablation") {
        pos = 0;
        while (pos < v.size()) {
          auto next_pos = v.find_first_of(':', pos);
          // cerr << "DBG param: " << pos << ' ' << next_pos << endl;
          int val;
          if (next_pos == string::npos) {
            val = StrToInt(v.substr(pos));
            pos = v.size();
          } else {
            val = StrToInt(v.substr(pos, next_pos - pos));
            pos = next_pos + 1;
          }
          
          LinearConstraint::ablation.insert(LinearConstraint::Ablation_Func(val));
        }
      } else if (k == "lp-level") {
        LinearConstraint::lp_level_limit = StrToInt(v);
      } else {
        cerr << "Warning: unknow parameter [" << k << "]" << endl;
      }
    }
  }

  // ofstream outfile("result_2_", ios::out | ios::trunc);

  LinearConstraint lc;
  if (!lc.read(in_path)) {
    cerr << "Error in reading file " << argv[1] << endl;
    return -2;
  }

  auto start = chrono::high_resolution_clock::now();

  Int ans = Solver::count(lc);

  auto end = chrono::high_resolution_clock::now();
  auto run_time =
      chrono::duration_cast<std::chrono::nanoseconds>(end - start) * 1e-9;

  // outfile << ans << ' ' << run_time.count() << endl;

  cout << "Number of solutions: " << ans << endl;

  // cout << "decompose and cache: " << lc.CD << ' ' << lc.CC << endl;
  cout << "run time: " << run_time.count() << endl;

  return 0;
}
