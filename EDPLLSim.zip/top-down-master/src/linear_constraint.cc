#include "linear_constraint.h"

unordered_map<LinearConstraint, Int, LinearConstraint::LChash>
    LinearConstraint::cache;
// gp_hash_table<LinearConstraint, Int, LinearConstraint::LChash>
//     LinearConstraint::cache;
gp_hash_table<vector<Int>, pair<int, Int>, LinearConstraint::VIHash>
    LinearConstraint::mp;
int LinearConstraint::CD = 0;
int LinearConstraint::CC = 0;
vector<Int> LinearConstraint::tmp;

const double LinearConstraint::EPS = 1e-2;

unordered_set<LinearConstraint::Ablation_Func> LinearConstraint::ablation;
int LinearConstraint::lp_level_limit = 1;

size_t LinearConstraint::LChash::operator()(const LinearConstraint &lc) const {
  int n = lc.getN(), m = lc.getM();
  int res = (n * base + m) % mod;
  for (const auto &p : lc.ranges) {
    res = res * base % mod;
    res = (res + p.first) % mod * base % mod;
    res = (res + p.second) % mod;
  }
  for (const auto &v : lc.matrix) {
    for (const auto &b : v) res = (res * base + b) % mod;
  }
  res = (res + mod) % mod;
  return hash<int>()(res);
}

size_t LinearConstraint::VIHash::operator()(const vector<Int> &vi) const {
  int res = 0;
  for (const Int &v : vi) res = (res * base + v) % mod;
  res = (res + mod) % mod;
  return hash<int>()(res);
}

int LinearConstraint::getN() const { return ranges.size(); }
int LinearConstraint::getM() const { return matrix.size(); }

int LinearConstraint::read(const string &file_name) {
  ifstream infile(file_name);

  if (!infile.is_open()) return 0;

  int n, m;
  infile >> n >> m;

  ranges.resize(n);
  matrix.resize(m, vector<Int>(n + 1));
  for (int i = 0; i < n; i++) infile >> ranges[i].first >> ranges[i].second;
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < n + 1; j++) infile >> matrix[i][j];
  }
  sort(matrix.begin(), matrix.end());

  infile.close();

  return 1;
}

void LinearConstraint::read(istream& infile) {
  int n, m;
  infile >> n >> m;

  ranges.resize(n);
  matrix.resize(m, vector<Int>(n + 1));
  for (int i = 0; i < n; i++) infile >> ranges[i].first >> ranges[i].second;
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < n + 1; j++) infile >> matrix[i][j];
  }
  sort(matrix.begin(), matrix.end());
}

void LinearConstraint::output() const {
  int n = getN(), m = getM();
  cerr << n << ' ' << m << '\n';
  for (int i = 0; i < n; i++)
    cerr << ranges[i].first << ' ' << ranges[i].second << '\n';
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < n + 1; j++) cerr << matrix[i][j] << ' ';
    cerr << endl;
  }
}

int LinearConstraint::size() { return getN() * getM(); }

Int LinearConstraint::getRange(int id) {
  if ((int)ranges.size() <= id) return 0;
  return ranges[id].second - ranges[id].first + 1;
}

Int LinearConstraint::getSpace() {
  int n = getN();
  Int res = 1;
  for (int i = 0; i < n; i++) {
    res *= getRange(i);
  }
  return res;
}

int LinearConstraint::select() {
  int id = -1;
  int n = getN();
  Int mn;
  for (int i = 0; i < n; i++) {
    if (id == -1 || getRange(i).cmp(mn) < 0) {
      mn = getRange(i);
      id = i;
    }
  }
  assert(mn.cmp(0) > 0);
  assert(~id);

  return id;
}

int getId(vector<int> &pa, int x) {
  return x ^ pa[x] ? pa[x] = getId(pa, pa[x]) : x;
}

vector<LinearConstraint> LinearConstraint::decompose() {
  int n = getN();
  vector<int> pa(n), num(n);
  for (int i = 0; i < n; i++) pa[i] = i;
  for (const auto &v : matrix) {
    int pos = -1;
    for (int i = 0; i < n; i++) {
      if (!v[i].cmp(0)) continue;
      if (pos == -1)
        pos = i;
      else
        pa[getId(pa, i)] = getId(pa, pos);
    }
  }

  int tot = 0;
  gp_hash_table<int, int> mp;
  // unordered_map<int, int> mp;
  for (int i = 0; i < n; i++) {
    getId(pa, i);
    if (mp.find(pa[i]) == mp.end()) mp[pa[i]] = tot++;
  }

  if (tot < 2) {
    assert(tot == 1);
    return vector<LinearConstraint>();
  }

  vector<LinearConstraint> res(tot);
  for (int i = 0; i < n; i++) {
    LinearConstraint &t = res[mp[pa[i]]];
    num[i] = t.getN();
    t.ranges.emplace_back(ranges[i]);
  }

  for (const auto &v : matrix) {
    int id = -1;
    for (int i = 0; i < n; i++) {
      if (!v[i].cmp(0)) continue;
      if (id == -1) {
        id = mp[pa[i]];
        res[id].matrix.emplace_back(vector<Int>(res[id].getN() + 1));
      }
      res[id].matrix.back()[num[i]] = v[i];
    }
    if (~id) res[id].matrix.back().back() = v.back();
  }

  return res;
}

Int LinearConstraint::simplify(int level) {
  tmp.resize(getM());

  Int t;
  int tt;
  bool tag, ctag = false, vis = true;
  do {
    tag = removeFixedVariables();

    t = redundancyDetectionSingle();
    if (t.cmp(0) >= 0)
      return t;
    else if (!t.cmp(-1))
      tag = ctag = true;

    tt = boundStrengtheningSingle();
    if (!tt)
      return 0;
    else if (tt == -1)
      tag = true;

    if (vis && coefficientStrengtheningSingle()) {
      tag = true;
    }

    if (vis && redundancyDetectionSubset()) {
      tag = ctag = true;
    }

    if (vis) {
      tt = parallelRows();
      if (!tt)
        return 0;
      else if (tt == -1)
        tag = ctag = true;
    }

    if (vis && level <= lp_level_limit) {
      t = LP();
      if (t.cmp(0) >= 0)
        return t;
      else if (!t.cmp(-1))
        tag = ctag = true;
    }
    vis = false;
  } while (tag);

  if (ctag) sort(matrix.begin(), matrix.end());

  return -1;
}

Int LinearConstraint::redundancyDetectionSingle() { // used to detect recursive boundaries, so no ablation
  bool tag = false;
  int n = getN(), m = getM();
  for (int i = 0; i < m; i++) {
    Int mx = 0, mn = 0;
    for (int j = 0; j < n; j++) {
      const Int &v = matrix[i][j];
      if (v == 0) continue;
      mx += max(v * ranges[j].first, v * ranges[j].second);
      mn += min(v * ranges[j].first, v * ranges[j].second);
    }

    if (matrix[i].back() < mn) return 0;
    if (mx.cmp(matrix[i].back()) <= 0) {
      swap(matrix[i], matrix.back());
      matrix.pop_back();
      tag = true;
      m--;
      i--;
    } else
      tmp[i] = mn;
  }

  if (matrix.empty()) {
    Int res(1);
    for (int i = 0; i < n; i++) res *= getRange(i);
    return res;
  }

  return tag - 2;
}

bool LinearConstraint::deleteVariable(int id) {
  if (id < 0 || id >= getN()) return false;
  if (getRange(id) != 1) return false;
  for (auto &vec : matrix) {
    vec.back() -= vec[id] * ranges[id].first;
    vec.erase(vec.begin() + id);
  }
  ranges.erase(ranges.begin() + id);
  return true;
}

bool LinearConstraint::removeFixedVariables() {
  if (ablation.count(kRemoveFixedVariables)) return false;

  Int val;
  bool tag = false;
  for (int i = 0; i < getN(); i++) {
    if (deleteVariable(i)) {
      tag = true;
      i--;
    }
  }
  return tag;
}

int LinearConstraint::boundStrengtheningSingle() {
  if (ablation.count(kBoundStrengtheningSingle)) return -2;

  int n = getN(), m = getM();
  // vector<Int> tmp(m);
  // tmp.assign(m, 0);
  // for (int i = 0; i < m; i++) {
  //   for (int j = 0; j < n; j++) {
  //     const Int &v = matrix[i][j];
  //     if (v == 0) continue;
  //     tmp[i] += min(v * ranges[j].first, v * ranges[j].second);
  //   }
  // }

  Int val;
  bool tag = false;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      const Int &v = matrix[j][i];
      if (!v.cmp(0)) continue;
      if (v.cmp(0) > 0) {
        val = matrix[j].back() - tmp[j] + v * ranges[i].first;

        mpz_fdiv_q(val.a, val.a, v.a);
        if (val.cmp(ranges[i].first) < 0) return 0;
        if (val.cmp(ranges[i].second) < 0) {
          tag = true;
          ranges[i].second = val;
        }
      } else {
        val = -matrix[j].back() + tmp[j] - v * ranges[i].second;

        mpz_cdiv_q(val.a, val.a, (-v).a);
        if (val.cmp(ranges[i].second) > 0) return 0;
        if (val.cmp(ranges[i].first) > 0) {
          tag = true;
          ranges[i].first = val;
        }
      }
    }
  }

  return tag - 2;
}

bool LinearConstraint::coefficientStrengtheningSingle() {
  if (ablation.count(kCoefficientStrengtheningSingle)) return 0;

  Int mx, u, t, d;
  bool tag = false;
  int n = getN();
  for (auto &v : matrix) {
    mx = 0;
    int num = 0;
    for (int i = 0; i < n; i++) {
      if (v[i] != 0) {
        num++;
        mx += max(v[i] * ranges[i].first, v[i] * ranges[i].second);
      }
    }

    if (num < 2) continue;

    for (int i = 0; i < n; i++) {
      if (v[i] == 0) continue;

      if (v[i].cmp(0) > 0) {
        u = mx - v[i] * ranges[i].second;
        d = v.back() - u - v[i] * (ranges[i].second - 1);
        if (v[i].cmp(d) >= 0 && d.cmp(0) > 0) {
          mx -= d * ranges[i].second;
          v[i] -= d;
          v.back() -= d * ranges[i].second;
          tag = true;
        }
      } else {
        u = mx - v[i] * ranges[i].first;
        d = v.back() - u - v[i] * (ranges[i].first + 1);
        if ((-v[i]).cmp(d) >= 0 && d.cmp(0) > 0) {
          mx += d * ranges[i].first;
          v[i] += d;
          v.back() += d * ranges[i].first;
          tag = true;
        }
      }

      if (v[i] == 0 && --num < 2) break;
    }
  }

  return tag;
}

bool LinearConstraint::redundancyDetectionSubset() {
  if (ablation.count(kRedundancyDetectionSubset)) return 0;

  bool tag = false;
  int m = getM(), n = getN();
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < m; j++) {
      if (i == j) continue;

      Int mn = 0;
      bool flag = true;
      for (int k = 0; k < n; k++) {
        const Int &v1 = matrix[i][k];
        const Int &v2 = matrix[j][k];
        if (v1 == 0)
          mn += min(v2 * ranges[k].first, v2 * ranges[k].second);
        else if (v1 != v2) {
          flag = false;
          break;
        }
      }

      if (flag && mn.cmp(matrix[j].back() - matrix[i].back()) >= 0) {
        tag = true;
        swap(matrix[i], matrix.back());
        matrix.pop_back();
        i--;
        m--;
        break;
      }
    }
  }

  return tag;
}

int LinearConstraint::parallelRows() {
  if (ablation.count(kParallelRows)) return -2;

  bool tag = false;
  mp.clear();
  vector<int> del;
  int m = getM(), n = getN();
  for (int i = 0; i < m; i++) {
    vector<Int> t(matrix[i].begin(), matrix[i].begin() + n);

    Int d = 0, d2 = 0;
    for (const Int &v : t) Int::gcd(d, d, v);
    assert(d.cmp(0) > 0);
    if (d.cmp(1) > 0) {
      for (Int& v : t) v /= d;
    }
    Int::gcd(d2, d, matrix[i].back());
    if (d2.cmp(1) > 0) {
      tag = true;
      for (Int& v : matrix[i]) v /= d2;
      d /= d2;
    }

    if (mp.find(t) == mp.end())
      mp[t] = make_pair(i, d);
    else {
      auto &p = mp[t];
      if (matrix[i].back() * p.second < matrix[p.first].back() * d) {
        del.push_back(p.first);
        p = make_pair(i, d);
      } else {
        del.push_back(i);
      }
      tag = true;
    }

    for (Int &v : t) v = -v;
    if (mp.find(t) != mp.end()) {
      const auto &p = mp[t];
      if (matrix[i].back() * p.second < matrix[p.first].back() * d * -1)
        return 0;
    }
  }
  sort(del.begin(), del.end(), greater<int>());
  for (int id : del) {
    swap(matrix[id], matrix.back());
    matrix.pop_back();
  }

  return tag - 2;
}

Int LinearConstraint::LP() {
  if (ablation.count(kBoundStrengtheningLP) &&
      ablation.count(kRedundancyDetectionLP)) return -2;

  int n = getN();
  int m = getM();

  // cerr << "before LP:" << endl;
  // output();
  // cerr << endl;

  // Initialize LP
  glp_prob* lp;
  lp = glp_create_prob();

  glp_add_rows(lp, m);
  for (int i = 0; i < m; i++) {
    glp_set_row_bnds(lp, i + 1, GLP_UP, 0, matrix[i].back().to_double());
  }

  glp_add_cols(lp, n);
  for (int i = 0; i < n; i++) {
    glp_set_col_bnds(lp, i + 1, GLP_DB, ranges[i].first.to_double(), ranges[i].second.to_double());
    glp_set_col_kind(lp, i + 1, GLP_IV);
  }

  int* iA = new int[m * n + 1];
  int* jA = new int[m * n + 1];
  double* vA = new double[m * n + 1];
  int idx = 1;
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < n; j++) {
      iA[idx] = i + 1;
      jA[idx] = j + 1;
      vA[idx++] = matrix[i][j].to_double();
    }
  }

  glp_load_matrix(lp, m * n, iA, jA, vA);
  delete []iA;
  delete []jA;
  delete []vA;

  glp_smcp lp_parm;
  glp_init_smcp(&lp_parm);
  lp_parm.msg_lev = GLP_MSG_ERR;

  glp_iocp mip_parm;
  glp_init_iocp(&mip_parm);
  mip_parm.msg_lev = GLP_MSG_ERR;

  // LP for variable bound
  int ret = boundStrengtheningLP(lp, &lp_parm, &mip_parm);
  if (ret == 0) return 0;

  Int sol = redundancyDetectionLP(lp, &lp_parm, &mip_parm);
  glp_delete_prob(lp);
  return sol;
}

int LinearConstraint::boundStrengtheningLP(glp_prob* lp, glp_smcp* lp_parm, glp_iocp* mip_parm) {
  if (ablation.count(kBoundStrengtheningLP)) return -2;

  int n = getN();
  Int l, u;
  bool tag = false;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      glp_set_obj_coef(lp, j + 1, i == j);
    }
    
    glp_set_obj_dir(lp, GLP_MAX);
    if (glp_simplex(lp, lp_parm) == 0 && glp_intopt(lp, mip_parm) == 0) {
      u = floor(glp_mip_obj_val(lp) + EPS);
      if (ranges[i].second.cmp(u) > 0) {
        ranges[i].second = u;
        tag = true;
      }
    }

    glp_set_obj_dir(lp, GLP_MIN);
    if (glp_simplex(lp, lp_parm) == 0 && glp_intopt(lp, mip_parm) == 0) {
      l = ceil(glp_mip_obj_val(lp) - EPS);
      if (ranges[i].first.cmp(l) < 0) {
        ranges[i].first = l;
        tag = true;
      }
    }

    if (ranges[i].first.cmp(ranges[i].second) > 0) { // lower > upper
      return 0;
    }

    glp_set_col_bnds(lp, i + 1, GLP_DB, ranges[i].first.to_double(), ranges[i].second.to_double());
  }

  return tag - 2;
}

Int LinearConstraint::redundancyDetectionLP(glp_prob* lp, glp_smcp* lp_parm, glp_iocp* mip_parm) {
  if (ablation.count(kRedundancyDetectionLP)) return -2;

  int m = getM();
  int n = getN();
  Int u;
  unordered_set<int> removeIdx;
  bool tag = false;
  for (int i = 0; i < m; i++) {
    glp_set_row_bnds(lp, i + 1, GLP_FR, 0, 0); // disable ith constraint

    for (int j = 0; j < n; j++) {
      glp_set_obj_coef(lp, j + 1, matrix[i][j].to_double());
    }

    glp_set_obj_dir(lp, GLP_MAX);
    if (glp_simplex(lp, lp_parm) == 0 && glp_intopt(lp, mip_parm) == 0) {
      u = floor(glp_mip_obj_val(lp) + EPS);
      if (u.cmp(matrix[i].back()) <= 0) { // ith constraint can be remove
        removeIdx.insert(i);
        tag = true;
      }
    }

    glp_set_row_bnds(lp, i + 1, GLP_UP, 0, matrix[i].back().to_double());  // enable ith constraint
  }

  int idx = 0;
  for (int i = 0; i < m; i++) {
    if (removeIdx.count(i) > 0) continue;
    swap(matrix[idx++], matrix[i]);
  }
  matrix.erase(matrix.begin() + idx, matrix.end());

  if (matrix.empty()) return getSpace();
  return tag - 2;
}

Int LinearConstraint::free_variable() {
  int n = getN();
  Int res(1);
  for (int i = 0; i < n; i++) {
    bool tag = true;
    for (const auto &v : matrix) {
      if (v[i].cmp(0)) {
        tag = false;
        break;
      }
    }
    if (tag) {
      assert(ranges[i].first.cmp(ranges[i].second) <= 0);
      res *= getRange(i);
      ranges.erase(ranges.begin() + i);
      for (auto &v : matrix) v.erase(v.begin() + i);
      n--;
      i--;
    }
  }
  return res;
}

bool LinearConstraint::operator==(const LinearConstraint &lc) const {
  if (getN() != lc.getN() || getM() != lc.getM()) return false;
  if (ranges != lc.ranges) return false;
  return matrix == lc.matrix;
}

void LinearConstraint::insertCache(const Int &v) {
  if (size() > MAX_MATRIX) return;
  if (cache.size() > MAX_CACHE) cache.clear();
  cache[*this] = v;
}

Int LinearConstraint::findCache() {
  if (size() > MAX_MATRIX || cache.find(*this) == cache.end()) return Int(-1);
  return cache[*this];
}
