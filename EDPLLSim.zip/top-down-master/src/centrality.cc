#include "centrality.h"

const int Centrality::inf = 0x3f3f3f3f;
queue<int> Centrality::Q;
vector<int> Centrality::tmp;
vector<vector<bool>> Centrality::e;
vector<vector<int>> Centrality::dis;
vector<vector<double>> Centrality::num;

int Centrality::solve(const LinearConstraint &lc) {
  int n = lc.getN();
  e.assign(n, vector<bool>(n, false));
  dis.assign(n, vector<int>(n, inf));
  num.assign(n, vector<double>(n, 0));

  for (const auto &v : lc.matrix) {
    tmp.clear();
    for (int i = 0; i < n; i++) {
      if (!v[i].cmp(0)) continue;
      for (int u : tmp) e[u][i] = e[i][u] = true;
      tmp.emplace_back(i);
    }
  }

  for (int s = 0; s < n; s++) {
    dis[s][s] = 0;
    num[s][s] = 1;
    Q.push(s);
    while (!Q.empty()) {
      int u = Q.front();
      Q.pop();
      for (int i = 0; i < n; i++) {
        if (!e[u][i]) continue;
        if (dis[s][i] == inf) {
          dis[s][i] = dis[s][u] + 1;
          Q.push(i);
        }
        if (dis[s][i] == dis[s][u] + 1) {
          num[s][i] += num[s][u];
        }
      }
    }
  }

  int id = -1;
  double mx = 0;
  for (int i = 0; i < n; i++) {
    double res = 0;
    for (int j = 0; j < n; j++) {
      if (i == j) continue;
      assert(dis[i][j] ^ inf);
      assert((num[i][j] - num[j][i]) < 1e-9);
      assert(dis[i][j] == dis[j][i]);
      for (int k = 0; k < n; k++) {
        if (k == i || k == j) continue;
        if (dis[j][k] < dis[j][i] + dis[i][k]) continue;
        assert(num[j][i] * num[i][k] <= num[j][k]);
        res += num[j][i] * num[i][k] / num[j][k];
      }
    }
    if (res > mx) {
      mx = res;
      id = i;
    }
  }
  return id;
}
