#ifndef __CENTRALITY_H__
#define __CENTRALITY_H__

#include <queue>
#include <vector>

#include "linear_constraint.h"

using namespace std;

class Centrality {
 public:
  static const int inf;
  static queue<int> Q;
  static vector<int> tmp;
  static vector<vector<bool>> e;
  static vector<vector<int>> dis;
  static vector<vector<double>> num;
  static int solve(const LinearConstraint &lc);
};

#endif