#ifndef __SOLVER_H__
#define __SOLVER_H__

#include "big_int.h"
#include "centrality.h"
#include "linear_constraint.h"

using namespace std;

class Solver {
 public:
  static Int count(LinearConstraint &lc);

  static Int count(LinearConstraint &lc, int level);
};

#endif