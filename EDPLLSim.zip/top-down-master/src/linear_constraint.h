#ifndef __LINEAR_CONSTRAINT_H__
#define __LINEAR_CONSTRAINT_H__

#include <assert.h>

#include <algorithm>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/hash_policy.hpp>
#include <fstream>
#include <functional>
#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <glpk.h>

#include "big_int.h"

#define RANGE_LIMIT 3
#define MAX_MATRIX 20
#define MAX_CACHE 9000000

using namespace std;
using namespace __gnu_pbds;

class LinearConstraint {
 public:
  // int n = 0, m = 0;               // number of variables and constraints
  vector<vector<Int>> matrix;     // coefficient matrix
  vector<pair<Int, Int>> ranges;  // variable value range

  struct LChash {
    static const int mod = 1000173169;
    static const long long base = 13331;
    size_t operator()(const LinearConstraint &lc) const;
  };

  struct VIHash {
    static const int mod = 1000173169;
    static const long long base = 13331;
    size_t operator()(const vector<Int> &vi) const;
  };

  static unordered_map<LinearConstraint, Int, LChash> cache;
  // static gp_hash_table<LinearConstraint, Int, LChash> cache;
  static gp_hash_table<vector<Int>, pair<int, Int>, VIHash> mp;
  static int CD, CC;
  static vector<Int> tmp;
  const static double EPS;

  int read(const string &file_name);
  void read(istream& infile);
  void output() const;

  int getN() const;
  int getM() const;
  int size();
  Int getRange(int id);
  Int getSpace();
  int select();
  vector<LinearConstraint> decompose();
  Int simplify(int level = 1);

  Int redundancyDetectionSingle();  // 0 conflict; -2 no change; -1 change
  bool deleteVariable(int id);
  bool removeFixedVariables();
  int boundStrengtheningSingle();  // 0 conflict; -2 no change; -1 change
  bool coefficientStrengtheningSingle();
  bool redundancyDetectionSubset();
  int parallelRows();  // 0 conflict; -2 no change; -1 change
  Int LP(); // 0 conflict; -2 no change; -1 change
  int boundStrengtheningLP(glp_prob* lp, glp_smcp* lp_parm, glp_iocp* mip_parm);
  Int redundancyDetectionLP(glp_prob* lp, glp_smcp* lp_parm, glp_iocp* mip_parm);

  void adjust();
  Int free_variable();

  bool operator==(const LinearConstraint &lc) const;
  void insertCache(const Int &v);
  Int findCache();

  enum Ablation_Func {
    // kRedundancyDetectionSingle = 1,
    kRemoveFixedVariables = 1,
    kBoundStrengtheningSingle = 2,
    kCoefficientStrengtheningSingle = 3,
    kRedundancyDetectionSubset = 4,
    kParallelRows = 5,
    kBoundStrengtheningLP = 6,
    kRedundancyDetectionLP = 7,
  };

  static unordered_set<Ablation_Func> ablation;
  static int lp_level_limit;
};

#endif