#include "solver.h"

Int Solver::count(LinearConstraint &lc) {
  return count(lc, 1);
}

Int Solver::count(LinearConstraint &lc, int level) {
  // lc.output();
  // cerr << endl;

  Int res = lc.simplify(level);
  if (res.cmp(0) >= 0) {
    lc.insertCache(res);
    return res;
  }

  Int factor = lc.free_variable();

  // lc.adjust();

  Int t = lc.findCache();
  if (t.cmp(-1) > 0) {
    lc.CC++;
    return t * factor;
  }

  vector<LinearConstraint> lcs = lc.decompose();
  if (!lcs.empty()) {
    lc.CD++;

    res = 1;
    for (auto &t : lcs) {
      if (!(res *= count(t, level + 1)).cmp(0)) {
        lc.insertCache(0);
        return 0;
      }
    }
    lc.insertCache(res);
    return res * factor;
  }

  int id = Centrality::solve(lc);
  if (id == -1) id = lc.select();

  res = 0;
  LinearConstraint tlc;
  for (Int i = lc.ranges[id].first; i.cmp(lc.ranges[id].second) <= 0; i++) {
    tlc = lc;
    tlc.ranges[id].first = tlc.ranges[id].second = i;
    tlc.deleteVariable(id);
    res += count(tlc, level + 1);
  }

  lc.insertCache(res);
  return res * factor;
}
