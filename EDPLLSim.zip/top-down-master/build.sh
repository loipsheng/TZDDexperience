cd src/

make
cp EDPLLSim ../EDPLLSim

cd ../
